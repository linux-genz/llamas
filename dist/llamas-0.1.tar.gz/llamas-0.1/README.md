# llamas
Local Manager POC on the way to production

Flowchart:

https://github.com/linux-genz/llamas/blob/master/llamas_flowchart.png
