from .netlink_mngr import NetlinkManager

NetlinkManager = NetlinkManager