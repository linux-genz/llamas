#!/usr/bin/python3

if __name__ == '__main__':
    from llamas import llamas_api
    llamas_api.main()